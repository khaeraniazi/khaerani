komputer_amount = int(input('Jumlah Komputer pertama: '))
service_time = int(input('Jumlah Komputer kedua: '))
drop_off = bool(input('Jumlah Komputer ketiga: '))
Pick_Up = bool(input('Jumlah Komputer keempat: '))

if (komputer_amount == 1 or komputer_amount == 2):
    base_fee = 500
    additional_fee = 0
elif(komputer_amount >= 3 and komputer_amount <= 10):
    base_fee = 100
    additional_fee = 10
elif(komputer_amount > 10):
    base_fee = 500
    additional_fee = 10

if (service_time < 9 or service_time > 21):
    base_fee = base_fee*2

if(drop_off == True and Pick_Up == True ):
    Total_Base_Fee = base_fee - (base_fee*0.015)

print(Total_Base_Fee)

