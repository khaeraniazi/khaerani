p = int(input("Masukkan angka pertama = "))
q = int(input("Masukkan angka kedua = "))
r = int(input("Masukkan angka ketiga = "))

if p==q==r:
    print("segitiga sama sisi")
elif (p or q or r <= 0) and (p >= (p+q)) or (q >= p+r) or (r >= p+q):
    print("segitiga ini tidak dapat dibangun")
elif (p==q or p==r or q==r):
    print ("segitiga sama kaki")
elif (p*p == q*q + r*r or q*q == p*p + r*r or r*r == q*q + p*p):
    print ("segitiga ini segitiga siku-siku")
else:
    print ("segitiga bebas")
